// ejercicio 1
const integer1 = 5;
const decimal1 = 3.5;

const sum = integer1 + decimal1;
const difference = integer1 - decimal1;
const product = integer1 * decimal1;
const quotient = integer1 / decimal1;
const exponent = Math.pow(integer1, decimal1);

console.log(`Sum: ${sum}`);
console.log(`Difference: ${difference}`);
console.log(`Product: ${product}`);
console.log(`Quotient: ${quotient}`);
console.log(`Exponent: ${exponent}`);

// ejercicio 2
const namenombre = 'John Doe';
const studenttId = '123456';

const fulllName = namenombre + ' ' + studentId;

console.log(fullName);

// ejercicio 3
const number = 42;
const stringNumber = number.toString();

console.log(stringNumber);

// ejercicio 4
const stringNumber2 = '3.14';
const number2 = parseFloat(stringNumber2);

console.log(number2);

//ejercicio 5
const mass = 10;
const earthGravity = 9.8;
const moonGravity = 1.62;
const marsGravity = 3.71;
const mercuryGravity = 3.7;

const earthWeight = mass * earthGravity;
const moonWeight = mass * moonGravity;
const marsWeight = mass * marsGravity;
const mercuryWeight = mass * mercuryGravity;

console.log(`Earth Weight: ${earthWeight} N`);
console.log(`Moon Weight: ${moonWeight} N`);
console.log(`Mars Weight: ${marsWeight} N`);
console.log(`Mercury Weight: ${mercuryWeight} N`);


const operationsForm = document.getElementById('operationsForm');
const num1 = document.getElementById('num1');
const num2 = document.getElementById('num2');
const sumButton = document.getElementById('sumButton');
const subtractButton = document.getElementById('subtractButton');
const multiplyButton = document.getElementById('multiplyButton');
const divideButton = document.getElementById('divideButton');
const exponentButton = document.getElementById('exponentButton');
const fullName = document.getElementById('fullName');
const studentId = document.getElementById('studentId');
const concatButton = document.getElementById('concatButton');
const numberInput = document.getElementById('numberInput');
const numberToStringButton = document.getElementById('numberToStringButton');
const stringInput = document.getElementById('stringInput');
const stringToNumberButton = document.getElementById('stringToNumberButton');
const massInput = document.getElementById('massInput');
const calculateWeightButton = document.getElementById('calculateWeightButton');

operationsForm.addEventListener('submit', (e) => {
    e.preventDefault();
   
});

sumButton.addEventListener('click', () => {
    const result = Number(num1.value) + Number(num2.value);
   
});

